import { View, Text } from 'react-native'
import React from 'react'

const Updates = () => {
  return (
    <View>
      <Text>Updates</Text>
    </View>
  )
}

export default Updates