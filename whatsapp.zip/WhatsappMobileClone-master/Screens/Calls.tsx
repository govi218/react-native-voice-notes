import { View, Text } from 'react-native'
import React from 'react'

const Calls = () => {
  return (
    <View>
      <Text>Calls</Text>
    </View>
  )
}

export default Calls